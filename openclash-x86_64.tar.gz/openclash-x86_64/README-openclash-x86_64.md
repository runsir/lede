# 只带 OpenClash 的 x86_64 软路由固件（Lean's LEDE + GitHub Actions）

这份方案在你的 fork（`runsir/lede`）里加 4 个文件，就能用 GitHub 的免费 Runner
编译一个 **x86_64、带 OpenClash、出厂即旁路模式** 的固件。

固件里只有：**LuCI + OpenClash（含 ruby 运行时）+ dnsmasq-full(nftset) +
kmod-nft-tproxy / kmod-tun / kmod-inet-diag + ttyd 网页终端 + design 主题 + 中文**。
不带 ssr-plus、passwall、turboacc、UPnP、DDNS、Docker、Samba 等任何其它插件。

- 默认 LAN：`192.168.1.2/24`，网关 / DNS：`192.168.1.1`，**DHCP 已关闭**
- 后台：<http://192.168.1.2>，用户名 `root`，密码 `password`（**请第一时间修改**）
- 所有物理网口都桥接进 `br-lan`，插哪个口都能进后台；WAN 已关闭（旁路不需要）
- 同时产出 BIOS（`combined.img.gz`）和 UEFI（`combined-efi.img.gz`）两种镜像

---

## 1. 文件清单

```
.github/workflows/build-openclash-x86_64.yml   # 编译流程
configs/x86_64-openclash.config                # 包选择（seed config）
configs/zz-openclash-bypass                    # 首次开机写入旁路网络配置
README-openclash-x86_64.md                     # 本文件
```

把它们放到**你的 fork 根目录**（和 `feeds.conf.default`、`target/` 同一层）即可：

```bash
cd lede            # 你的 fork 克隆
mkdir -p .github/workflows configs
cp /path/to/openclash-x86_64/.github/workflows/build-openclash-x86_64.yml .github/workflows/
cp /path/to/openclash-x86_64/configs/x86_64-openclash.config configs/
cp /path/to/openclash-x86_64/configs/zz-openclash-bypass configs/
cp /path/to/openclash-x86_64/README-openclash-x86_64.md .

git add .github/workflows/build-openclash-x86_64.yml configs README-openclash-x86_64.md
git commit -m "ci: build x86_64 OpenClash bypass firmware"
git push
```

> 注意：Lean 源码的 `.gitignore` 里有 `/files`，所以**不要**把脚本放进
> `files/` 再提交（会被忽略）。本方案把脚本放在 `configs/`，由 workflow 在
> 编译前 `install` 到 `files/etc/uci-defaults/`，这是 OpenWrt 的标准 rootfs
> overlay 机制，能在镜像里生效。
> `zz-` 前缀保证它在其它 `uci-defaults` 之后执行。

---

## 2. 触发编译

仓库页面 → **Actions** → 左侧 **Build OpenClash x86_64** → **Run workflow**。

> 刚 fork 的仓库第一次进 Actions 会提示 “Workflows aren't being run on this
> forked repository”，点绿色按钮启用即可。
> Lean 源码自带一个 `.github/workflows/openwrt-ci.yml`（每周定时、默认配置），
> 和本方案无关；如果不想让它占用 Actions，可以在 Actions 页面把它禁用或删掉。

- 可选参数 `openclash_ref`：OpenClash 的分支或标签。
  默认 `master`；如果某天 master 编译失败，填一个已知可用的标签，例如 `v0.48.002`。
- 推送 `v*` 标签（如 `v1.0`）时也会自动编译，并**自动创建 Release** 附上固件。
- 普通 `git push` 分支不会触发（避免浪费 Actions 时间）。

单次编译约 **2～3 小时**（4 核 Runner）。公开仓库的 Actions 分钟数免费。

产物在 Actions 运行页面的 **Artifacts**：

| Artifact | 内容 |
| --- | --- |
| `openclash-x86_64-firmware` | `*.combined.img.gz`、`*.combined-efi.img.gz`、manifest、sha256、配置信息 |
| `openclash-x86_64-packages` | `bin/packages/x86_64/` 下的 ipk（以后装插件/kmod 用，注意内核版本必须一致） |
| `build-log` | 仅编译失败时上传，用来定位错误 |

---

## 3. 刷机

`.img.gz` 解压后得到 `.img`，是**磁盘镜像**（不是 ISO，不能用 Ventoy 直接引导）：

- 写 U 盘：Rufus（Windows，选 DD 模式）/ balenaEtcher / `dd if=xx.img of=/dev/sdX bs=4M status=progress`
- 写软路由内置硬盘：PE 或 Linux 下直接 dd，或用 `physdiskwrite`
- BIOS 老机器用 `*-combined.img.gz`，UEFI 机器用 `*-combined-efi.img.gz`
- 写完从该盘启动即可；首次启动稍慢（要创建 overlay），属正常
- 本固件根分区固定 1 GiB，overlay（可写空间）约 800 MB，装在更大的盘上也不会
  自动占满全盘；要装 Docker 之类的大件请把 `CONFIG_TARGET_ROOTFS_PARTSIZE` 调大重编

---

## 4. 首次开机 & 旁路拓扑

```
        光猫
         │
      主路由 192.168.1.1（继续负责拨号 / DHCP / 无线）
         │  LAN 口
      交换机 ──── 你的电脑 / AP / 其它设备
         │
   旁路设备 192.168.1.2（本固件，关 DHCP，网关/DNS 指向 192.168.1.1）
```

1. 用网线把旁路设备的**任意网口**接到主路由的 LAN 口（或交换机）。
2. 电脑从主路由拿 IP（`192.168.1.x`），浏览器打开 <http://192.168.1.2>，
   `root` / `password` 登录，先在「系统 → 管理权」里改密码。
3. 在主路由的 DHCP 设置里，把**网关**和 **DNS** 都指向 `192.168.1.2`。
   这样全网设备自动走旁路；也可以只给个别设备静态指定。
4. 如果主路由不方便改 DHCP：把需要翻墙的设备的网关/DNS 手动设为 `192.168.1.2`。

> 旁路设备本身不需要 DHCP 服务，`zz-openclash-bypass` 已经关掉了 DHCPv4/v6/RA。
> 若你的主路由网段不是 `192.168.1.0/24`，请在编译前改
> `configs/zz-openclash-bypass` 顶部的 `LAN_IP` / `LAN_GW`，
> 或者在能进后台之后到「网络 → 接口 → LAN」里改（改完记得网关也要改）。

> 注意：所有网口都在同一个网桥里，**只接一根网线到主路由/交换机**。
> 不要把本机的两个网口接到同一台交换机上（会形成环路、导致全网广播风暴）。

**不要关闭防火墙。** OpenClash 的 nft 规则是挂在 `inet fw4` 表上的，
关掉防火墙代理会直接失效（这也是本方案保留 firewall4 的原因）。

---

## 5. 配置 OpenClash

固件里 OpenClash 默认**不启动**（还没有订阅，启动了也没意义）：

1. 「服务 → OpenClash → 配置文件」→ 在订阅栏填入机场订阅 → **添加** → **更新**。
2. 「插件设置 → 版本更新」里下载 **Clash Meta 内核**（首次需要联网访问 GitHub，
   国内网络可能较慢）。下载失败时可以把内核文件手动放到
   `/etc/openclash/core/clash_meta` 并 `chmod +x`。
3. 回到「运行状态」选好配置文件，把「启用」打开，保存并应用。
4. 旁路模式下推荐「Fake-IP（增强模式）」；DNS 相关保持默认即可，
   OpenClash 会接管局域网 53 端口。

默认端口：混合 `7893`、HTTP `7890`、SOCKS `7891`、面板 `9090`（按需在 LuCI 里改）。

---

## 6. IPv6

固件保留了完整的 IPv6 组件（odhcp6c/odhcpd、ip6tables、nftables IPv6），
旁路默认关闭了 LAN 的 DHCPv6/RA，避免和主路由冲突。

要在旁路模式下代理 IPv6，需要：主路由正常下发 IPv6 前缀 → 旁路设备能从 LAN
拿到 IPv6 地址/默认路由 → 在 OpenClash「插件设置」里开启 IPv6 相关开关。
如果暂时不用 IPv6，什么都不用做，IPv4 不受影响。

---

## 7. 常见问题

**编译失败 / OpenClash 相关报错**
- 先下载 `build-log` artifact，看最后 50 行。
- 多半是 OpenClash `master` 又改了依赖或者上游下载源抖动。
  在 Actions 里用 `openclash_ref=v0.48.002` 这种固定标签重跑一次。
- 如果是 `make download` 失败：直接重跑，GitHub Runner 到 sourceforge /
  cache.ruby-lang.org 的线路偶尔会断。

**为什么编译要这么久**
- OpenClash 依赖 `ruby`（解析 YAML 配置），ruby 需要先编译 host 版再交叉编译
  目标版，这一步就要十几二十分钟；再加上工具链和内核，2～3 小时是正常的。

**首次开机进不去后台**
- 旁路设备没有 DHCP。电脑要能从主路由拿到 `192.168.1.x` 的地址；
  如果单独接电脑调试，请给电脑手动配静态 IP `192.168.1.10/24`。
- 确认插的是旁路设备的网口（所有物理网口都已桥接，任意一个都行）。

**想换成别的网段 / 换回普通路由**
- 改 `configs/zz-openclash-bypass` 顶部的 4 个变量后重新编译；
- 或登录后台在 LuCI 里改 LAN 地址、网关、重新开 DHCP。

**想加别的插件**
- 用 `openclash-x86_64-packages` 里的 ipk 在「系统 → 软件包」上传安装；
  内核模块（kmod-*）必须和固件同一内核版本，混用会装不上。

**为什么没有 turboacc / ssr-plus**
- turboacc 的流量分载会和 OpenClash 的透明代理抢流量，属于常见冲突源，已移除；
- ssr-plus 与 OpenClash 功能重叠，按「只带 OpenClash」的要求移除。

---

## 8. 技术说明（做了哪些查证）

- **源码**：你的 fork 就是 Lean's LEDE（`luci` feed 指向 `openwrt-25.12` 分支，
  内核默认 6.18，防火墙为 firewall4/nftables）。
- **OpenClash**：`vernesong/OpenClash` 的 `luci-app-openclash`，当前 master 为
  0.48.002。它仍然是 Lua/CBI 页面，依赖 `luci-compat` + `luci-lua-runtime`
  （内部走 `ucode-mod-lua` 桥），因此在 Lean 这棵 LuCI 上可以正常工作。
- **依赖**：Makefile 要求 `dnsmasq-full bash curl ca-bundle ip-full ruby ruby-yaml
  kmod-tun unzip`；在 firewall4 下自动选 `kmod-nft-tproxy` 和
  `dnsmasq-full` 的 nftset 支持。以上全部在 `.config` 里显式写出，CI 会逐项校验，
  缺一个就 red，不会出现「编译成功但固件里没有 OpenClash」。
- **po2lmo 顺序问题**：OpenClash 的 Makefile 没声明 `luci-base` 依赖，但打包时
  需要 luci-base 的 host 工具 `po2lmo`，`-j` 并行下可能偶发找不到。CI 在编译前
  给它的 `DEPENDS` 补上 `luci-base`，保证先编 luci-base。
- **防火墙**：OpenClash 的规则写进 `inet fw4` 表，所以必须保留 firewall4；
  旁路同一网段转发依赖 lan zone 默认的 `forward ACCEPT`，不需要额外改防火墙。
- **镜像**：x86/64 generic，squashfs，1 GiB 根分区（其中 squashfs 之外的
  ~800 MB 自动成为 overlay，ruby + OpenClash + 常用 ipk 够用），同时生成
  BIOS/UEFI 镜像。
- **Runner**：`ubuntu-22.04`。Lean 的 lede 在 24.04 上因为 gcc/python 版本
  容易出各种奇怪问题，22.04 是社区验证过的组合；job 超时设 350 分钟。
